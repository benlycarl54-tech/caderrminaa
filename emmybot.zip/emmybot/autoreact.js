/**
   * Created By EmmyHenz
   * Contact Me on wa.me/2349125042727
*/

const emojis = [
    "🔥",      // Fire - most popular reaction
    "❤️",      // Red heart - classic love
    "💯",      // 100 - perfect/approval
    "🎉",      // Party - celebration
    "👏",      // Clapping - appreciation
    "💪",      // Flexed muscle - strength/power
    "✨",      // Sparkles - magical/special
    "⚡",      // Lightning - energy/power
    "💎",      // Diamond - valuable/precious
    "🚀",      // Rocket - growth/success
    "🏆",      // Trophy - winner/achievement
    "👑",      // Crown - royal/best
    "💖",      // Sparkling heart - extra love
    "🤩",      // Star eyes - amazed
    "🙌",      // Raised hands - praise/celebration
    "💥",      // Explosion - impact/wow
    "🌟",      // Star - excellence
    "😍",      // Heart eyes - love it
    "🔝",      // Top - highest quality
    "🎯"       // Target - on point/accurate
];

// Export the emojis array
module.exports = { emojis };