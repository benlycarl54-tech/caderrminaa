/**
   * Created By EmmyHenz
   * Contact Me on wa.me/2349125042727
*/
module.exports = {
  apps: [{
    name: "tg-bot",
    script: "./server.js",
    watch: false,          // FIX: watch:true was restarting on any file change
    autorestart: true,
    max_memory_restart: "800M",
    node_args: "--max-old-space-size=700",
    env: {
      NODE_ENV: "production"
    },
    error_file: "./logs/error.log",
    out_file: "./logs/output.log",
    log_date_format: "YYYY-MM-DD HH:mm:ss",
    combine_logs: true,
    time: true,
    restart_delay: 5000,
    max_restarts: 10,
    min_uptime: "10s",
    wait_ready: false,     // FIX: was true but server.js never sends process.send('ready')
                           // PM2 was killing app after listen_timeout (30s) every time
    listen_timeout: 10000
  }]
};
