/**
 * EMMY HENZ V3.5 — Single Session Bot
 * Created By EmmyHenz · wa.me/2349125042727
 * 
 * Private repo — DO NOT DISTRIBUTE THIS FILE DIRECTLY.
 * Users run index.js which downloads and runs this automatically.
 */

'use strict';
const {
    default: makeWASocket,
    jidDecode,
    DisconnectReason,
    makeCacheableSignalKeyStore,
    useMultiFileAuthState,
    Browsers,
    getContentType,
    proto,
    jidNormalizedUser,
    downloadContentFromMessage,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');

const NodeCache  = require('node-cache');
const { Boom }   = require('@hapi/boom');
const pino       = require('pino');
const FileType   = require('file-type');
const fs         = require('fs');
const path       = require('path');
const readline   = require('readline');
const chalk      = require('chalk');

// ── Load runtime config (written by index.js launcher) ───────────────────────
let runtimeConfig = {};
const configFile = path.join(__dirname, 'runtimeConfig.json');
if (fs.existsSync(configFile)) {
    try { runtimeConfig = JSON.parse(fs.readFileSync(configFile, 'utf8')); } catch (_) {}
}

// ── Load bot helpers ──────────────────────────────────────────────────────────
const { writeExif, imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, reSize }       = require('./lib/myfunc');
const { handleMessages, handleGroupParticipantUpdate, handleStatus, handleCalls } = require('./main');
const { setDefaultBioOnStartup } = require('./commands/setbotbio');
const { emojis }                 = require('./autoreact');

// Apply runtime config to global settings (so main.js / commands can read them)
global.runtimeConfig = runtimeConfig;

// ── Channels that trigger auto-react ─────────────────────────────────────────
// Emmy: add or remove your channel JIDs here in the private repo
const AUTO_REACT_CHANNELS = [
    '120363410694173688@newsletter',
    '120363425304543494@newsletter',
    '120363420647483556@newsletter',
];

// ── Session path ──────────────────────────────────────────────────────────────
const SESSION_DIR  = path.join(__dirname, '..', 'session'); // stored outside .emmybot/
const SESSION_PATH = path.join(SESSION_DIR, 'creds');

// ── Constants ─────────────────────────────────────────────────────────────────
const sleep       = ms => new Promise(r => setTimeout(r, ms));
const MAX_RETRIES = 10;
const CONN_TIMEOUT    = 30000;
const KEEP_ALIVE_INT  = 60000;
const MAX_KA_FAILURES = 5;

let retryCount = 0;

// ── Suppress noisy Baileys logs ───────────────────────────────────────────────
const _origErr  = console.error.bind(console);
const _SUPPRESS = ['_chains','chainKey','registrationId','currentRatchet',
    'ephemeralKeyPair','pendingPreKey','indexInfo','baseKey','remoteIdentityKey'];
console.error = (...a) => {
    const s = a.map(x => typeof x === 'string' ? x : (x?.message || '')).join(' ');
    if (_SUPPRESS.some(k => s.includes(k)) || s.includes('Bad MAC')) return;
    _origErr(...a);
};

// ── Process stability ─────────────────────────────────────────────────────────
process.on('uncaughtException', error => {
    const msg = error?.message || String(error);
    if (msg.includes('Bad MAC')) {
        console.log('⚠️  Bad MAC — cleaning pre-keys...');
        try {
            if (fs.existsSync(SESSION_PATH)) {
                fs.readdirSync(SESSION_PATH).forEach(f => {
                    if (f !== 'creds.json' &&
                        (f.startsWith('pre-key-') || f.startsWith('sender-key-') ||
                         f.startsWith('session-') || f.startsWith('app-state-'))) {
                        try { fs.unlinkSync(path.join(SESSION_PATH, f)); } catch (_) {}
                    }
                });
            }
        } catch (_) {}
        return;
    }
    if (msg.includes('Connection Closed') || msg.includes('ECONNRESET') ||
        msg.includes('ETIMEDOUT') || msg.includes('write EPIPE')) return;
    _origErr('❌ Exception:', msg);
});

process.on('unhandledRejection', reason => {
    const msg = reason?.message ? reason.message : String(reason);
    if (msg.includes('Bad MAC') || msg.includes('Connection Closed') ||
        msg.includes('ECONNRESET') || msg.includes('ETIMEDOUT') ||
        msg.includes('write EPIPE')) return;
    _origErr('❌ Rejection:', msg);
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function cleanSessionFiles(dir) {
    if (!fs.existsSync(dir)) return;
    fs.readdirSync(dir).forEach(f => {
        if (f === 'creds.json') return;
        const fp = path.join(dir, f);
        try { fs.lstatSync(fp).isDirectory() ? fs.rmSync(fp, {recursive:true}) : fs.unlinkSync(fp); } catch (_) {}
    });
    console.log(chalk.green('Session cleaned (credentials preserved).'));
}

function hasValidCredentials() {
    const credsPath = path.join(SESSION_PATH, 'creds.json');
    if (!fs.existsSync(credsPath)) return false;
    try {
        const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
        return !!(creds?.me?.id);
    } catch { return false; }
}

// ── Get phone number (from config or prompt) ──────────────────────────────────
async function getPhoneNumber() {
    // First try runtimeConfig (set by index.js from user's config.js)
    if (runtimeConfig.phoneNumber) return runtimeConfig.phoneNumber;

    // Fallback: ask in terminal
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => {
        rl.question(chalk.yellow('\n📱 Enter your WhatsApp number (country code, no + or 0): '), ans => {
            rl.close();
            resolve(ans.trim().replace(/\D/g, ''));
        });
    });
}

// ── Make socket ───────────────────────────────────────────────────────────────
function makeSocket(state) {
    let store = { messages: {}, loadMessage: async () => null, bind: () => {} };
    return makeWASocket({
        logger:                   pino({ level: 'silent' }),
        printQRInTerminal:        false,
        auth:                     state,
        version:                  [2, 3000, 1033942132],
        browser:                  Browsers.ubuntu('Edge'),
        getMessage:               async key => (await store.loadMessage(jidNormalizedUser(key.remoteJid), key.id))?.message || '',
        shouldSyncHistoryMessage: msg => !!msg.syncType,
        connectTimeoutMs:         CONN_TIMEOUT,
        keepAliveIntervalMs:      KEEP_ALIVE_INT,
        maxRetries:               MAX_RETRIES,
        retryDelayMs:             2000,
        markOnlineOnConnect:      true,
        generateHighQualityLinkPreview: true,
        syncFullHistory:          false,
        transactionOpts:          { maxCommitRetries: 10, delayBetweenTriesMs: 3000 },
        msgRetryCounterCache:     new NodeCache({ stdTTL: 3600, useClones: false }),
        defaultQueryTimeoutMs:    60000,
    }, store);
}

// ── Main bot start ────────────────────────────────────────────────────────────
async function startBot() {
    const phoneNumber = await getPhoneNumber();
    if (!phoneNumber || phoneNumber.length < 10) {
        console.log(chalk.red('❌ Invalid phone number. Please check your config.js and restart.'));
        process.exit(1);
    }

    // Ensure session directory exists
    if (!fs.existsSync(SESSION_PATH)) fs.mkdirSync(SESSION_PATH, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(SESSION_PATH);
    const bad = makeSocket(state);

    // ── Request pairing code if not yet registered ────────────────────────────
    if (!state.creds.registered) {
        const _requestCode = async (attempt = 1) => {
            try {
                let code = await bad.requestPairingCode(phoneNumber, 'EMMYHENZ');
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log();
                console.log(chalk.bold(chalk.cyan('╔══════════════════════════════════════════════╗')));
                console.log(chalk.bold(chalk.cyan('║          YOUR PAIRING CODE IS READY          ║')));
                console.log(chalk.bold(chalk.cyan('╠══════════════════════════════════════════════╣')));
                console.log(chalk.bold(chalk.cyan(`║    Code:  ${chalk.yellow(code.padEnd(10))}                    ║`)));
                console.log(chalk.bold(chalk.cyan('║                                              ║')));
                console.log(chalk.bold(chalk.cyan('║  WhatsApp → Settings → Linked Devices        ║')));
                console.log(chalk.bold(chalk.cyan('║  → Link a Device → Link with phone number    ║')));
                console.log(chalk.bold(chalk.cyan('╚══════════════════════════════════════════════╝')));
                console.log();
            } catch (err) {
                console.log(chalk.red(`Pairing attempt ${attempt} failed: ${err.message}`));
                if (attempt < 4) setTimeout(() => _requestCode(attempt + 1), attempt * 3000);
                else console.log(chalk.red('All pairing attempts failed. Restart the bot.'));
            }
        };
        setTimeout(() => _requestCode(), 5000);
    }

    // ── Attach decodeJid ─────────────────────────────────────────────────────
    bad.decodeJid = jid => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const d = jidDecode(jid) || {};
            return d.user && d.server ? `${d.user}@${d.server}` : jid;
        }
        return jid;
    };

    // ── Convenience methods ───────────────────────────────────────────────────
    bad.public   = (runtimeConfig.mode || 'public') === 'public';
    bad.sendText = (jid, text, quoted = '', options) => bad.sendMessage(jid, { text, ...options }, { quoted });

    bad.sendImageAsSticker = async (jid, pth, quoted, options = {}) => {
        let buff = Buffer.isBuffer(pth) ? pth
            : /^data:.*?\/.*?;base64,/i.test(pth) ? Buffer.from(pth.split`,`[1], 'base64')
            : /^https?:\/\//.test(pth) ? await getBuffer(pth)
            : fs.existsSync(pth) ? fs.readFileSync(pth) : Buffer.alloc(0);
        const buffer = (options.packname || options.author)
            ? await writeExifImg(buff, options) : await imageToWebp(buff);
        await bad.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
            .then(() => { try { fs.unlinkSync(buffer); } catch (_) {} });
    };

    bad.getFile = async (PATH, save) => {
        let res, data = Buffer.isBuffer(PATH) ? PATH
            : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64')
            : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH))
            : fs.existsSync(PATH) ? fs.readFileSync(PATH) : Buffer.alloc(0);
        const type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        const filename = path.join(__dirname, '../tmp/', Date.now() + '.' + type.ext);
        if (data && save) { fs.mkdirSync(path.dirname(filename), {recursive:true}); await fs.promises.writeFile(filename, data); }
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    bad.ments = (teks = '') =>
        teks.includes('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [];

    // ── Health monitoring ─────────────────────────────────────────────────────
    let lastMsgTime = Date.now();
    let kaInterval, connValidator, kaFailures = 0;

    const startKA = () => {
        if (kaInterval) clearInterval(kaInterval);
        kaInterval = setInterval(async () => {
            try   { await bad.sendPresenceUpdate('unavailable'); kaFailures = 0; }
            catch { kaFailures++; if (kaFailures >= MAX_KA_FAILURES) { clearInterval(kaInterval); bad.end(new Error('Keep-alive failed')); } }
        }, KEEP_ALIVE_INT);
    };

    const startValidator = () => {
        if (connValidator) clearInterval(connValidator);
        connValidator = setInterval(async () => {
            if (Date.now() - lastMsgTime > 20 * 60 * 1000) {
                try   { await bad.sendPresenceUpdate('composing'); await sleep(1000); await bad.sendPresenceUpdate('available'); }
                catch { bad.end(new Error('Health check failed')); }
            }
        }, 30 * 60 * 1000);
    };

    // ── messages.upsert ───────────────────────────────────────────────────────
    bad.ev.on('messages.upsert', async chatUpdate => {
        lastMsgTime = Date.now();
        try {
            const mek = chatUpdate.messages[0];

            // ── AUTO-REACT ─────────────────────────────────────────────────────
            // MUST be before !mek.message guard (newsletter posts arrive with null message)
            const jid = mek?.key?.remoteJid;
            const isChannelPost = (jid && jid.endsWith('@newsletter')) ||
                                   mek?.message?.newsletterMessage ||
                                   mek?.messageStubType === 68;

            if (isChannelPost) {
                if (AUTO_REACT_CHANNELS.includes(jid) && chatUpdate.type === 'notify') {
                    const serverId = mek.key?.server_id || mek.newsletterServerId;
                    if (serverId) {
                        const emoji = emojis[Math.floor(Math.random() * emojis.length)];
                        await sleep(1500);
                        bad.newsletterReactMessage(jid, serverId.toString(), emoji)
                            .then(() => console.log(`✅ Auto-reacted to ${jid} with ${emoji}`))
                            .catch(e => console.error(`❌ Auto-react failed: ${e.message}`));
                    }
                }
                return;
            }
            // ── END AUTO-REACT ─────────────────────────────────────────────────

            if (!mek.message) return;

            mek.message = Object.keys(mek.message)[0] === 'ephemeralMessage'
                ? mek.message.ephemeralMessage.message : mek.message;

            // Status
            if (mek.key?.remoteJid === 'status@broadcast') { await handleStatus(bad, chatUpdate); return; }

            if (!bad.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

            try {
                await handleMessages(bad, chatUpdate, true);
            } catch (e) {
                console.error('Error in handleMessages:', e.message);
            }
        } catch (e) {
            console.error('Error in messages.upsert:', e.message);
        }
    });

    bad.ev.on('group-participants.update', async update => { await handleGroupParticipantUpdate(bad, update); });
    bad.ev.on('status.update',             async status  => { await handleStatus(bad, status); });
    bad.ev.on('messages.reaction',         async r       => { await handleStatus(bad, r); });
    bad.ev.on('call',                      async call    => { await handleCalls(bad, call); });
    bad.ev.on('creds.update', saveCreds);

    // ── connection.update ─────────────────────────────────────────────────────
    bad.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
        if (connection === 'connecting') {
            console.log(chalk.yellow(`🔄 Connecting...`));
            return;
        }

        if (connection === 'open') {
            retryCount = 0;
            startKA(); startValidator();
            console.log(chalk.green.bold(`✅ EMMY HENZ V3.5 is ONLINE! Number: ${phoneNumber}`));

            // Auto-follow Emmy's channels
            for (const ch of AUTO_REACT_CHANNELS) {
                try { await bad.newsletterFollow(ch); } catch (_) {}
            }

            await setDefaultBioOnStartup(bad).catch(() => {});
            console.log(chalk.cyan(`< ====[ ❤️‍🔥🎊𝐄𝐌𝐌𝐘𝐇𝐄𝐍𝐙-𝐕3.5🎊❤️‍🔥 ]====[ Online ]====>`));
            return;
        }

        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            console.log(chalk.yellow(`❌ Connection closed. Reason: ${reason}`));

            if (kaInterval)    { clearInterval(kaInterval);    kaInterval = null; }
            if (connValidator) { clearInterval(connValidator);  connValidator = null; }

            // No reconnect for these
            if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red('🚪 Logged out. Cleaning session files...'));
                cleanSessionFiles(SESSION_PATH);
                console.log(chalk.yellow('Please restart the bot and re-pair.'));
                return;
            }
            if (reason === DisconnectReason.connectionReplaced) {
                console.log(chalk.blue('🔄 Connection replaced.'));
                return;
            }

            retryCount++;
            if (retryCount >= MAX_RETRIES) {
                console.error(chalk.red(`❌ Max retries (${MAX_RETRIES}) reached. Stopping.`));
                process.exit(1);
            }

            // Reconnect with appropriate delay based on error
            const delays = {
                [DisconnectReason.badSession]:       [true, 2000],
                [DisconnectReason.connectionClosed]: [false, 1000],
                [DisconnectReason.connectionLost]:   [false, 1500],
                [DisconnectReason.restartRequired]:  [false, 2000],
                [DisconnectReason.timedOut]:         [false, 2000],
                428: [false, 8000],
                440: [false, 1000],
                401: [true,  5000],
                403: [true,  3000],
                429: [false, 10000 + Math.random() * 15000],
            };

            const [clean, delay] = delays[reason] || [reason >= 400 && reason < 600, 3000];
            if (clean) cleanSessionFiles(SESSION_PATH);
            await sleep(delay);
            startBot();
        }
    });
}

// ── Start ─────────────────────────────────────────────────────────────────────
startBot().catch(e => {
    console.error(chalk.red(`Fatal: ${e.message}`));
    process.exit(1);
});
