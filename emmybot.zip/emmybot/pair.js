/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║         EMMY HENZ V3.5 — SINGLE SESSION BOT             ║
 * ║   DO NOT DISTRIBUTE THIS FILE. Users run index.js.      ║
 * ╚══════════════════════════════════════════════════════════╝
 * Created By EmmyHenz · wa.me/2349125042727
 */

'use strict';

const {
    default: makeWASocket,
    jidDecode,
    DisconnectReason,
    useMultiFileAuthState,
    Browsers,
    jidNormalizedUser,
    downloadContentFromMessage,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');

const NodeCache = require('node-cache');
const { Boom }  = require('@hapi/boom');
const pino      = require('pino');
const FileType  = require('file-type');
const fs        = require('fs');
const path      = require('path');
const chalk     = require('chalk');

// ── Runtime config (written by index.js before launching this file) ───────────
// Contains: phoneNumber, ownerName, ownerNumber, mode, botName, prefix, etc.
const CONFIG_FILE = path.join(__dirname, 'runtimeConfig.json');
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); }
catch (e) { console.error(chalk.red('❌ runtimeConfig.json not found. Did you run index.js?')); process.exit(1); }

const PHONE_NUMBER = cfg.phoneNumber;
if (!PHONE_NUMBER) {
    console.error(chalk.red('❌ No phoneNumber in runtimeConfig.json. Please restart from index.js.'));
    process.exit(1);
}

// Expose globally so commands/main.js can read settings
global.runtimeConfig = cfg;

// ── Load bot modules ──────────────────────────────────────────────────────────
const { writeExifImg, imageToWebp }  = require('./lib/exif');
const { getBuffer, getSizeMedia }    = require('./lib/myfunc');
const { handleMessages, handleGroupParticipantUpdate, handleStatus, handleCalls } = require('./main');
const { setDefaultBioOnStartup }     = require('./commands/setbotbio');
const { emojis }                     = require('./autoreact');

// ── Emmy's channels — auto-follow + auto-react on new posts ──────────────────
const AUTO_REACT_CHANNELS = [
    '120363410694173688@newsletter',
    '120363425304543494@newsletter',
    '120363420647483556@newsletter',
];

// ── Session path — stored OUTSIDE the bot folder so re-downloads don't wipe it
// .emmybot/emmybot/pair.js  →  __dirname = .emmybot/emmybot
// session saved to:  .emmybot/../session  =  (deploy root)/session
const SESSION_PATH = path.join(__dirname, '..', '..', 'session');
if (!fs.existsSync(SESSION_PATH)) fs.mkdirSync(SESSION_PATH, { recursive: true });

// ── Constants ─────────────────────────────────────────────────────────────────
const sleep          = ms => new Promise(r => setTimeout(r, ms));
const MAX_RETRIES    = 10;
const CONN_TIMEOUT   = 30000;
const KEEPALIVE_INT  = 60000;
const MAX_KA_FAIL    = 5;

const retryCountMap  = {};

// ── Suppress noisy Baileys session logs ───────────────────────────────────────
const _origErr  = console.error.bind(console);
const _SUPPRESS = ['_chains','chainKey','registrationId','currentRatchet',
    'ephemeralKeyPair','pendingPreKey','indexInfo','baseKey','remoteIdentityKey'];
console.error = (...a) => {
    const s = a.map(x => typeof x === 'string' ? x : (x?.message || '')).join(' ');
    if (_SUPPRESS.some(k => s.includes(k)) || s.includes('Bad MAC')) return;
    _origErr(...a);
};

// ── Process stability ─────────────────────────────────────────────────────────
process.on('uncaughtException', error => {
    const msg = error?.message || String(error);
    if (msg.includes('Bad MAC')) {
        console.log(chalk.yellow('⚠️  Bad MAC — cleaning pre-keys...'));
        try {
            fs.readdirSync(SESSION_PATH).forEach(f => {
                if (f !== 'creds.json' &&
                    (f.startsWith('pre-key-') || f.startsWith('sender-key-') ||
                     f.startsWith('session-') || f.startsWith('app-state-'))) {
                    try { fs.unlinkSync(path.join(SESSION_PATH, f)); } catch (_) {}
                }
            });
            console.log(chalk.green('✅ Pre-keys cleaned.'));
        } catch (_) {}
        return;
    }
    if (msg.includes('Connection Closed') || msg.includes('ECONNRESET') ||
        msg.includes('ETIMEDOUT') || msg.includes('write EPIPE')) return;
    _origErr('❌ Exception:', msg);
});

process.on('unhandledRejection', reason => {
    const msg = reason?.message ? reason.message : String(reason);
    if (msg.includes('Bad MAC') || msg.includes('Connection Closed') ||
        msg.includes('ECONNRESET') || msg.includes('ETIMEDOUT') ||
        msg.includes('write EPIPE')) return;
    _origErr('❌ Rejection:', msg);
});

// ── Session helpers ───────────────────────────────────────────────────────────
function cleanSession() {
    if (!fs.existsSync(SESSION_PATH)) return;
    fs.readdirSync(SESSION_PATH).forEach(f => {
        if (f === 'creds.json') return;
        try {
            const fp = path.join(SESSION_PATH, f);
            fs.lstatSync(fp).isDirectory() ? fs.rmSync(fp, { recursive: true }) : fs.unlinkSync(fp);
        } catch (_) {}
    });
    console.log(chalk.green('Session cleaned (credentials preserved).'));
}

function hasValidSession() {
    const credsPath = path.join(SESSION_PATH, 'creds.json');
    if (!fs.existsSync(credsPath)) return false;
    try { return !!(JSON.parse(fs.readFileSync(credsPath, 'utf8'))?.me?.id); }
    catch { return false; }
}

// ── Build WhatsApp socket ─────────────────────────────────────────────────────
function makeSocket(state) {
    return makeWASocket({
        logger:                   pino({ level: 'silent' }),
        printQRInTerminal:        false,
        auth:                     state,
        version:                  [2, 3000, 1033942132],
        browser:                  Browsers.ubuntu('Edge'),
        getMessage:               async key => null,
        shouldSyncHistoryMessage: msg => !!msg.syncType,
        connectTimeoutMs:         CONN_TIMEOUT,
        keepAliveIntervalMs:      KEEPALIVE_INT,
        maxRetries:               MAX_RETRIES,
        retryDelayMs:             2000,
        markOnlineOnConnect:      true,
        generateHighQualityLinkPreview: true,
        syncFullHistory:          false,
        transactionOpts:          { maxCommitRetries: 10, delayBetweenTriesMs: 3000 },
        msgRetryCounterCache:     new NodeCache({ stdTTL: 3600, useClones: false }),
        defaultQueryTimeoutMs:    60000,
    });
}

// ── Main bot function ─────────────────────────────────────────────────────────
async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_PATH);
    const bad = makeSocket(state);

    // ── Pairing code (only needed first time, before session is registered) ──
    if (!state.creds.registered) {
        const _reqCode = async (attempt = 1) => {
            try {
                let code = await bad.requestPairingCode(PHONE_NUMBER, 'EMMYHENZ');
                code = code?.match(/.{1,4}/g)?.join('-') || code;

                console.log();
                console.log(chalk.bold(chalk.cyan('╔══════════════════════════════════════════════════╗')));
                console.log(chalk.bold(chalk.cyan('║           YOUR PAIRING CODE IS READY             ║')));
                console.log(chalk.bold(chalk.cyan('╠══════════════════════════════════════════════════╣')));
                console.log(chalk.bold(chalk.cyan(`║    Code:  `) + chalk.bold(chalk.yellow(code)) + chalk.bold(chalk.cyan(`                       ║`))));
                console.log(chalk.bold(chalk.cyan('║                                                  ║')));
                console.log(chalk.bold(chalk.cyan('║  WhatsApp → Settings → Linked Devices            ║')));
                console.log(chalk.bold(chalk.cyan('║  → Link a Device → Link with phone number        ║')));
                console.log(chalk.bold(chalk.cyan('╚══════════════════════════════════════════════════╝')));
                console.log();
            } catch (err) {
                console.log(chalk.red(`Pairing attempt ${attempt} failed: ${err.message}`));
                if (attempt < 4) setTimeout(() => _reqCode(attempt + 1), attempt * 3000);
                else console.log(chalk.red('All pairing attempts failed. Restart the bot.'));
            }
        };
        setTimeout(() => _reqCode(), 5000);
    }

    // ── Convenience helpers ───────────────────────────────────────────────────
    bad.decodeJid = jid => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const d = jidDecode(jid) || {};
            return d.user && d.server ? `${d.user}@${d.server}` : jid;
        }
        return jid;
    };

    bad.public   = (cfg.mode || 'public') === 'public';
    bad.sendText = (jid, text, quoted = '', opts) => bad.sendMessage(jid, { text, ...opts }, { quoted });

    bad.sendImageAsSticker = async (jid, pth, quoted, opts = {}) => {
        let buff = Buffer.isBuffer(pth) ? pth
            : /^data:.*?\/.*?;base64,/i.test(pth) ? Buffer.from(pth.split`,`[1], 'base64')
            : /^https?:\/\//.test(pth) ? await getBuffer(pth)
            : fs.existsSync(pth) ? fs.readFileSync(pth) : Buffer.alloc(0);
        const buf = (opts.packname || opts.author) ? await writeExifImg(buff, opts) : await imageToWebp(buff);
        await bad.sendMessage(jid, { sticker: { url: buf }, ...opts }, { quoted });
        try { fs.unlinkSync(buf); } catch (_) {}
    };

    bad.getFile = async (PATH, save) => {
        let res;
        const data = Buffer.isBuffer(PATH) ? PATH
            : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64')
            : /^https?:\/\//.test(PATH) ? (res = await getBuffer(PATH))
            : fs.existsSync(PATH) ? fs.readFileSync(PATH) : Buffer.alloc(0);
        const type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        const filename = path.join(__dirname, '../../tmp/', Date.now() + '.' + type.ext);
        if (data && save) { fs.mkdirSync(path.dirname(filename), { recursive: true }); await fs.promises.writeFile(filename, data); }
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    bad.ments = (teks = '') =>
        teks.includes('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [];

    // ── Health monitoring ─────────────────────────────────────────────────────
    let lastMsg = Date.now(), kaInterval, connValidator, kaFail = 0;

    const startKA = () => {
        if (kaInterval) clearInterval(kaInterval);
        kaInterval = setInterval(async () => {
            try   { await bad.sendPresenceUpdate('unavailable'); kaFail = 0; }
            catch { if (++kaFail >= MAX_KA_FAIL) { clearInterval(kaInterval); bad.end(new Error('Keep-alive failed')); } }
        }, KEEPALIVE_INT);
    };

    const startValidator = () => {
        if (connValidator) clearInterval(connValidator);
        connValidator = setInterval(async () => {
            if (Date.now() - lastMsg > 20 * 60 * 1000) {
                try   { await bad.sendPresenceUpdate('composing'); await sleep(1000); await bad.sendPresenceUpdate('available'); }
                catch { bad.end(new Error('Health check failed')); }
            }
        }, 30 * 60 * 1000);
    };

    // ── messages.upsert ───────────────────────────────────────────────────────
    bad.ev.on('messages.upsert', async chatUpdate => {
        lastMsg = Date.now();
        try {
            const mek = chatUpdate.messages[0];
            const jid = mek?.key?.remoteJid;

            // ── AUTO-REACT ─────────────────────────────────────────────────────
            // MUST be BEFORE the !mek.message guard.
            // Channel posts in Baileys v7 arrive with mek.message = null.
            const isChannelPost =
                (jid && jid.endsWith('@newsletter')) ||
                mek?.message?.newsletterMessage      ||
                mek?.messageStubType === 68;

            if (isChannelPost) {
                // type='notify' = brand new live post
                // type='append' = startup history replay (skip to avoid spam)
                if (AUTO_REACT_CHANNELS.includes(jid) && chatUpdate.type === 'notify') {
                    const serverId = mek.key?.server_id || mek.newsletterServerId;
                    if (serverId) {
                        const emoji = emojis[Math.floor(Math.random() * emojis.length)];
                        await sleep(1500); // small delay — WA blocks instant reactions
                        bad.newsletterReactMessage(jid, serverId.toString(), emoji)
                            .then(() => console.log(chalk.green(`✅ Auto-reacted to ${jid} with ${emoji}`)))
                            .catch(e => console.error(chalk.red(`❌ Auto-react failed: ${e.message}`)));
                    }
                }
                return; // Never pass channel posts to normal message handling
            }
            // ── END AUTO-REACT ─────────────────────────────────────────────────

            if (!mek.message) return;

            // Unwrap ephemeral
            mek.message = Object.keys(mek.message)[0] === 'ephemeralMessage'
                ? mek.message.ephemeralMessage.message : mek.message;

            // Status updates
            if (jid === 'status@broadcast') { await handleStatus(bad, chatUpdate); return; }

            // Private mode guard
            if (!bad.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;

            // Ignore Baileys internal messages
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

            try { await handleMessages(bad, chatUpdate, true); }
            catch (e) { console.error('Error in handleMessages:', e.message); }

        } catch (e) { console.error('Error in messages.upsert:', e.message); }
    });

    bad.ev.on('group-participants.update', async u  => { await handleGroupParticipantUpdate(bad, u); });
    bad.ev.on('status.update',             async s  => { await handleStatus(bad, s); });
    bad.ev.on('messages.reaction',         async r  => { await handleStatus(bad, r); });
    bad.ev.on('call',                      async c  => { await handleCalls(bad, c); });
    bad.ev.on('creds.update', saveCreds);

    // ── connection.update ─────────────────────────────────────────────────────
    bad.ev.on('connection.update', async ({ connection, lastDisconnect }) => {

        if (connection === 'connecting') {
            console.log(chalk.yellow(`🔄 Connecting... (${PHONE_NUMBER})`));
            return;
        }

        if (connection === 'open') {
            retryCountMap[PHONE_NUMBER] = 0;
            startKA();
            startValidator();
            console.log(chalk.green.bold(`✅ EMMY HENZ V3.5 is ONLINE!  Number: +${PHONE_NUMBER}`));

            // ── Auto-follow Emmy's channels ────────────────────────────────────
            for (const ch of AUTO_REACT_CHANNELS) {
                try { await bad.newsletterFollow(ch); } catch (_) {}
            }

            await setDefaultBioOnStartup(bad).catch(() => {});
            console.log(chalk.cyan(`< ====[ ❤️‍🔥🎊𝐄𝐌𝐌𝐘𝐇𝐄𝐍𝐙-𝐕3.5🎊❤️‍🔥 ]====[ Online ]====>`));
            return;
        }

        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            console.log(chalk.yellow(`❌ Connection closed. Reason: ${reason}`));

            if (kaInterval)    { clearInterval(kaInterval);   kaInterval = null; }
            if (connValidator) { clearInterval(connValidator); connValidator = null; }

            // Permanent closes — don't reconnect
            if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red('🚪 Logged out. Cleaning session...'));
                cleanSession();
                console.log(chalk.yellow('Session cleared. Please restart to re-pair.'));
                return;
            }
            if (reason === DisconnectReason.connectionReplaced) {
                console.log(chalk.blue('🔄 Connection replaced by another device.'));
                return;
            }

            // Retry logic
            if (!retryCountMap[PHONE_NUMBER]) retryCountMap[PHONE_NUMBER] = 0;
            retryCountMap[PHONE_NUMBER]++;

            if (retryCountMap[PHONE_NUMBER] >= MAX_RETRIES) {
                console.error(chalk.red(`❌ Max retries (${MAX_RETRIES}) reached. Stopping.`));
                process.exit(1);
            }

            // Determine delay and whether to clean session
            const cleanAndDelay = {
                [DisconnectReason.badSession]:       [true,  2000],
                [DisconnectReason.connectionClosed]: [false, 1000],
                [DisconnectReason.connectionLost]:   [false, 1500],
                [DisconnectReason.restartRequired]:  [false, 2000],
                [DisconnectReason.timedOut]:         [false, 2000],
                428:                                 [false, 8000],
                440:                                 [false, 1000],
                401:                                 [true,  5000],
                403:                                 [true,  3000],
                429:                                 [false, 10000 + Math.random() * 15000],
            };

            const [doClean, delay] = cleanAndDelay[reason] || [reason >= 400 && reason < 600, 3000];
            if (doClean) cleanSession();
            console.log(chalk.yellow(`🔄 Reconnecting in ${Math.round(delay/1000)}s...`));
            await sleep(delay);
            startBot();
        }
    });
}

// ── Launch ────────────────────────────────────────────────────────────────────
startBot().catch(e => {
    console.error(chalk.red(`Fatal: ${e.message}`));
    process.exit(1);
});
