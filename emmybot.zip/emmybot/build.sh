#!/bin/bash
# ╔══════════════════════════════════════════════════════════╗
# ║     EMMY HENZ — Private Repo Build & Deploy Script      ║
# ║  Run this to create the emmybot.zip for distribution    ║
# ╚══════════════════════════════════════════════════════════╝
# 
# Usage: chmod +x build.sh && ./build.sh

set -e

ZIPNAME="emmybot.zip"
DEPLOY_URL=""  # optional: sftp/scp URL to auto-upload

echo "🔨 Building EMMY HENZ V3.5 bot bundle..."

# Clean old zip
rm -f "$ZIPNAME"

# Files and folders to include in the zip
# (adjust if your folder structure is different)
zip -r "$ZIPNAME" \
    pair.js \
    main.js \
    autoreact.js \
    settings.js \
    config.js \
    commands/ \
    lib/ \
    data/ \
    src/ \
    package.json \
    --exclude "*.log" \
    --exclude "node_modules/*" \
    --exclude ".git/*" \
    --exclude "kingbadboitimewisher/*" \
    --exclude "session/*" \
    --exclude "*.zip" \
    --exclude "runtimeConfig.json"

echo "✅ Built: $ZIPNAME ($(du -sh $ZIPNAME | cut -f1))"

# Optional: auto-upload to your server
# Uncomment and fill in DEPLOY_URL if you want auto-deploy
# scp "$ZIPNAME" "$DEPLOY_URL"
# echo "🚀 Deployed to server!"

echo ""
echo "📋 Next steps:"
echo "   1. Upload $ZIPNAME to your server"
echo "   2. Make sure the URL in public/index.js _S variable points to it"
echo "   3. Users who run .update will get this new version"
echo ""
